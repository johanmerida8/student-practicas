@extends("templates.main")
@section("title", "Professor list")
@section("content")
<a href="/newprofessor" class="btn btn-primary">New professor</a>
<table class="table table-primary">
    <br>
    <thead>
        <tr>
            <th>
                First name
            </th>
            <th>
                Last name
            </th>
            <th>
                Birth date
            </th>
            <th>
                City
            </th>
            <th>
                Salary
            </th>
        </tr>
    </thead>
    <tbody>
        @foreach ($professors as $professor)
        <tr>
            <td>
                {{ $professor->firstName }}
            </td>
            <td>
                {{ $professor->lastName }}
            </td>
            <td>
                {{ $professor->birthDate }}
            </td>
            <td>
                {{ $professor->city }}
            </td>
            <td>
                {{ $professor->salary }}
            </td>
            <td>
                {{ Form::open(["url" => "/professors", "method" => "delete"]) }}
                    <input type="hidden" name="id" value="{{ $professor->id }}">
                    <a href="{{ '/editprofessors/' . $professor->id }}" class="btn btn-primary">Edit</a>
                    <button type="submit" class="btn btn-primary">Delete</button>
                {{ Form::close() }}
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@stop