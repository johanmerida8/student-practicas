@extends("templates.main")
@section("title", "Edit Professor")
@section("content")
{{ Form::open(["url" => "/professors", "method" => "put"]) }}
    <input type="hidden" name="id" value="{{ $professor->id }}">
    <div>
        First name:
        <input type="text" 
               name="firstName" 
               class="form-control" 
               value="{{ $professor->firstName }}">
    </div>
    <div>
        Last name:
        <input type="text" 
            name="lastName" 
            class="form-control" 
            value="{{ $professor->lastName }}">
    </div>
    <div>
        Birth date:
        <input type="text" name="birthDate" class="form-control" value="{{ $professor->birthDate }}">
    </div>

    <div>
        City:
        <input type="text" name="city" class="form-control" value="{{ $professor->city }}">
    </div>
    <div>
        Salary:
        <input type="number" name="salary" class="form-control" value="{{ $professor->salary }}">
    </div>
    <div>
        <button type="submit" class="btn btn-primary">Submit</button>
        <a href="/listprofessors" class="btn btn-primary">Go back</a>
    </div>
{{ Form::close() }}
@stop