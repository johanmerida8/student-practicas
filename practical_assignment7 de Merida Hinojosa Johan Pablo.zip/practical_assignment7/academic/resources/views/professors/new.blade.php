@extends("templates.main")
@section("title", "New Professor")
@section("content")
<form action="/professors" method="post">
    @csrf
    <div>
        First name:
        <input type="text" name="firstName" class="form-control">
    </div>
    <div>
        Last name:
        <input type="text" name="lastName" class="form-control">
    </div>
    <div>
        Birth date:
        <input type="text" name="birthDate" class="form-control">
    </div>
    <div>
        City:
        <input type="text" name="city" class="form-control">
    </div>
    <div>
        Salary:
        <input type="number" name="salary" class="form-control">
    </div>
    <div>
        <button type="submit" class="btn btn-primary">Submit</button>
        <a href="/listprofessors" class="btn btn-primary">Go back</a>
    </div>
</form>
@stop