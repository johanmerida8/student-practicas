
<?php $__env->startSection("title", "New Professor"); ?>
<?php $__env->startSection("content"); ?>
<form action="/professors" method="post">
    <?php echo csrf_field(); ?>
    <div>
        First name:
        <input type="text" name="firstName" class="form-control">
    </div>
    <div>
        Last name:
        <input type="text" name="lastName" class="form-control">
    </div>
    <div>
        Birth date:
        <input type="text" name="birthDate" class="form-control">
    </div>
    <div>
        City:
        <input type="text" name="city" class="form-control">
    </div>
    <div>
        Salary:
        <input type="number" name="salary" class="form-control">
    </div>
    <div>
        <button type="submit" class="btn btn-primary">Submit</button>
        <a href="/listprofessors" class="btn btn-primary">Go back</a>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("templates.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NITRO\Documents\PW2_B_1-2022-master\STUDENT\UNIDAD4\practical_assignment7\academic\resources\views/professors/new.blade.php ENDPATH**/ ?>