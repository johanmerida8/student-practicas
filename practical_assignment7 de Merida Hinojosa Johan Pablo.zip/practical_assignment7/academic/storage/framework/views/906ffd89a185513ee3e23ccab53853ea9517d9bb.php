
<?php $__env->startSection("title", "Professor list"); ?>
<?php $__env->startSection("content"); ?>
<a href="/newprofessor" class="btn btn-primary">New professor</a>
<table class="table table-primary">
    <br>
    <thead>
        <tr>
            <th>
                First name
            </th>
            <th>
                Last name
            </th>
            <th>
                Birth date
            </th>
            <th>
                City
            </th>
            <th>
                Salary
            </th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $professors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $professor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php echo e($professor->firstName); ?>

            </td>
            <td>
                <?php echo e($professor->lastName); ?>

            </td>
            <td>
                <?php echo e($professor->birthDate); ?>

            </td>
            <td>
                <?php echo e($professor->city); ?>

            </td>
            <td>
                <?php echo e($professor->salary); ?>

            </td>
            <td>
                <?php echo e(Form::open(["url" => "/professors", "method" => "delete"])); ?>

                    <input type="hidden" name="id" value="<?php echo e($professor->id); ?>">
                    <a href="<?php echo e('/editprofessors/' . $professor->id); ?>" class="btn btn-primary">Edit</a>
                    <button type="submit" class="btn btn-primary">Delete</button>
                <?php echo e(Form::close()); ?>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("templates.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NITRO\Documents\PW2_B_1-2022-master\STUDENT\UNIDAD4\practical_assignment7\academic\resources\views/professors/list.blade.php ENDPATH**/ ?>