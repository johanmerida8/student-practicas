<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Professor;

class ProfessorController extends Controller
{
    //
    public function getProfessors() {
        return Professor::all();
    }

    public function listProfessors() {
        return view("professors.list", ["professors" => Professor::all()]);
    }
    public function newProfessor() {
        return view("professors.new");
    }

    public function postProfessor(Request $request) {
        Professor::create([
            "firstName" => $request->firstName,
            "lastName" => $request->lastName,
            "birthDate" => $request->birthDate,
            "city" => $request->city,
            "salary" => $request->salary,
        ]);
        return view("professors.list", ["professors" => Professor::all()]);
    }

    public function putProfessor(Request $request) {
        $professor = Professor::where(["id" => $request->id])->first();
        $professor->firstName = $request->firstName;
        $professor->lastName = $request->lastName;
        $professor->birthDate = $request->birthDate;
        $professor->city = $request->city;
        $professor->salary = $request->salary;
        $professor->update();
        return view("products.list", ["products" => Product::all()]);
    }
    public function deleteProfessor(Request $request) {
        $professor = Professor::where(["id" => $request->id])->first();
        $professor->delete();
        return view("professors.list", ["professors" => Professor::all()]);
    }

    public function editProfessor($id) {
        $professor = Professor::where(["id" => $id])->first();
        return view("professors.edit", ["professor" => $professor]);
    }
}
