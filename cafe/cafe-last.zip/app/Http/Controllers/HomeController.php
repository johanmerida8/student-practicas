<?php

namespace App\Http\Controllers;
use App\Models\Menu;
use App\Models\Pedido;
use App\Models\Cliente;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index() 
    {
        return view('home.index', ["menus" => Menu::all()]);
    }

    public function pedido()
    {
        return view("home.pedido", ["clientes" => Cliente::all()]);
    }

    public function guardarPedido(Request $request) {
        Pedido::create([
            "menu" => 1,
            "cliente" => $request->cliente,
            "quantity" => $request->quantity,
            "totalprice" => $request->totalprice,
        ]);
        return view('home.index', ["menus" => Menu::all()]);
    }
    
}
