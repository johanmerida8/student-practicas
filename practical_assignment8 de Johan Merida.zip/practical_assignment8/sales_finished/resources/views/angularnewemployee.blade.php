@extends('layouts.master')
@section('title', 'New Employee')
@section('content')
<script type="text/javascript">
    var app = angular.module('EmployeeAddModule', []);
    app.controller('EmployeeAddController', ($scope, $http) => {
        $scope.employee = {};




        $scope.addEmployee = () => {
            $http.post('/ajaxemployees', $scope.employee).then((result) => {
                if (result.data.result === 1) {
                    window.location.href = '/ajaxemployeelist';
                }
            });
        }
    })
</script>
<div class="container" ng-app="EmployeeAddModule" ng-controller="EmployeeAddController">
    <form>
        <div class="form-group">
            <label for="txtFirstName">First name</label>
            <input id="txtFirstName" class="form-control" ng-model="employee.firstName" />
        </div>
        <div class="form-group">
            <label for="txtLastName">Last name</label>
            <input id="txtLastName" class="form-control" ng-model="employee.lastName" />
        </div>

        <div class="form-group">
            <label for="txtBirthDate">Birth Date</label>
            <input id="txtBirthDate" class="form-control" ng-model="employee.birthDate" />
        </div>

        <div class="form-group">
            <label for="txtAddress">City</label>
            <input id="txtAddress" class="form-control" ng-model="employee.city" />
        </div>

        <div class="form-group">
            <label for="txtAddress">Address</label>
            <input id="txtAddress" class="form-control" ng-model="employee.address" />
        </div>

        <div class="form-group">
            <label for="txtAddress">Photo</label>
            <input id="txtAddress" class="form-control" ng-model="employee.photo" />
        </div>
       
        
        
        <div class="form-group">
            
            <label for="txtUsername">Username</label>
            <input id="txtUsername" class="form-control" ng-model="employee.username" />
        </div>
        <div class="form-group">
            <label for="txtEmail">Email</label>
            <input id="txtEmail" class="form-control" ng-model="employee.email" />
        </div>
        <div class="form-group">
            <label for="txtPassword">Password</label>
            <input id="txtPassword" class="form-control" type="password" ng-model="employee.password" />
        </div>
        <input type="button" class="btn btn-primary" value="Send" ng-click="addEmployee()" />
        <a href="/employees" class="btn btn-primary">Back</a>
    </form>
</div>
@stop