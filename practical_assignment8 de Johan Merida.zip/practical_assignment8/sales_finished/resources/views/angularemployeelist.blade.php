@extends('layouts.master')
@section('title', 'Employee List')
@section('content')
<script type="text/javascript">
    var app = angular.module('EmployeeListModule', []);
    app.controller('EmployeeListController', ($scope, $http) => {
        $scope.employees = [];

        $scope.getEmployees = () => {
            $http.get('/ajaxemployees').then((result) => {
                $scope.employees = result.data;
            })
        }


        angular.element(document).ready(() => {
            $scope.getEmployees()
        });

        $scope.deleteEmployee = (id) => {
            $http.delete(`/ajaxemployees/${id}`).then((result) => {
                $scope.getEmployees()
            })
        }
    })
</script>
<div class="container" ng-app="EmployeeListModule" ng-controller="EmployeeListController">
    <h2>Employees List</h2>
    <table class="table table-dark">
        <thead>
            <tr>
                <th>
                    City
                </th>
                <th>
                    First Name
                </th>
                <th>
                    Last Name
                </th>
                <th>
                    Address
                </th>
            </tr>
        </thead>
        <tbody>
            <tr ng-repeat="employee in employees">
                <td>
                    @{{ employee.city }}
                </td>
                <td>
                    @{{ employee.firstName }}
                </td>
                <td>
                    @{{ employee.lastName }}
                </td>
                <td>
                    @{{ employee.address }}
                </td>
                <td>
                    <a href="@{{ '/ajaxeditemployee/' + employee.id }}" class="btn btn-primary">Edit</a>
                    <button ng-click="deleteEmployee(employee.id)" class="btn btn-danger">Delete</button>
                </td>
            </tr>
        </tbody>
    </table>
    <a href="/ajaxnewemployee" class="btn btn-primary">New Employee</a>
</div>
@stop