@extends('layouts.master')
@section('title', 'Main Page')
@section('content')
    <h2>
        Welcome to the Sales System
    </h2>
@stop
