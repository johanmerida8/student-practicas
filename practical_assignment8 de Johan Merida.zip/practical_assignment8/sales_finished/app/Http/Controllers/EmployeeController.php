<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\Employee;
use DB;

class EmployeeController extends Controller
{
    //
    public function getEmployees(){
        return view('employeesList',[
            'employees' => Employee::all()
        ]);
    }

    public function showNewEmployee(){
        return view ('newEmployee');
    }

    public function postEmployee(Request $request){
        try{
            DB::beginTransaction();
            $requestData = $request->all();

            $user = User::create([
                'name' => $requestData['username'],
                'email' => $requestData['email'],
                'password' => Hash::make($requestData['password'])
            ]);

            Employee::create([
                'firstName' => $requestData['firstName'],
                'lastName' => $requestData['lastName'],
                'birthDate' => $requestData['birthDate'],
                'city' => $requestData['city'],
                'address' => $requestData['address'],
                'photo' => $requestData['photo'],
                'userId' => $user->id
            ]);
            
        }catch(Exception $ex){
            DB::rollback();
        }
        return redirect ('/employees');
    }
}
