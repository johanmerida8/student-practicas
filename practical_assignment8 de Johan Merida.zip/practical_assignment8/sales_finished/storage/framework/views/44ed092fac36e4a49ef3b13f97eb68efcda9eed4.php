<?php $__env->startSection('title', 'Main Page'); ?>
<?php $__env->startSection('content'); ?>
    <h2>
        Welcome to the Sales System
    </h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NITRO\Documents\PW2_B_1-2022-master\STUDENT\UNIDAD4\sales_finished\resources\views/dashboard.blade.php ENDPATH**/ ?>