<?php $__env->startSection('title', 'Customer List'); ?>
<?php $__env->startSection('content'); ?>
<script type="text/javascript">
    var app = angular.module('CustomerListModule', []);
    app.controller('CustomerListController', ($scope, $http) => {
        $scope.customers = [];

        angular.element(document).ready(() => {
            $http.get('/ajaxcustomers').then((result) => {
                $scope.customers = result.data;
            });
        });
    })
</script>
<div class="container" ng-app="CustomerListModule" ng-controller="CustomerListController">
    <h2>Customers List</h2>
    <table class="table table-dark">
        <thead>
            <tr>
                <th>
                    NIT
                </th>
                <th>
                    First Name
                </th>
                <th>
                    Last Name
                </th>
                <th>
                    Address
                </th>
            </tr>
        </thead>
        <tbody>
            <tr ng-repeat="customer in customers">
                <td>
                    {{ customer.nit }}
                </td>
                <td>
                    {{ customer.firstName }}
                </td>
                <td>
                    {{ customer.lastName }}
                </td>
                <td>
                    {{ customer.address }}
                </td>
            </tr>
        </tbody>
    </table>
    <a href="/ajaxnewcustomer" class="btn btn-primary">New Customer</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NITRO\Documents\PW2_B_1-2022-master\STUDENT\UNIDAD4\sales_finished\resources\views/angularcustomerlist.blade.php ENDPATH**/ ?>